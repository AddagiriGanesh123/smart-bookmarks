const Appointment = require('../models/Appointment');
const Patient = require('../models/Patient');
const notif = require('./notificationController');

module.exports = {
  getAll: async (req, res) => {
    try { res.json(await Appointment.findAll(req.query)); }
    catch (err) { res.status(500).json({ error: err.message }); }
  },

  getById: async (req, res) => {
    try {
      const a = await Appointment.findById(req.params.id);
      if (!a) return res.status(404).json({ error: 'Not found' });
      res.json(a);
    } catch (err) { res.status(500).json({ error: err.message }); }
  },

  create: async (req, res) => {
    try {
      const id = await Appointment.create(req.body);
      const appt = await Appointment.findById(id);
      const patient = await Patient.findById(appt.patient_id);
      notif.notifyAppointmentScheduled(patient, appt).catch(console.error);
      res.status(201).json({ success: true, id });
    } catch (err) { res.status(500).json({ error: err.message }); }
  },

  update: async (req, res) => {
    try {
      const appt = await Appointment.findById(req.params.id);
      if (!appt) return res.status(404).json({ error: 'Not found' });
      await Appointment.update(req.params.id, req.body);
      if (req.body.status === 'cancelled') {
        const patient = await Patient.findById(appt.patient_id);
        notif.notifyAppointmentCancelled(patient, appt).catch(console.error);
      }
      res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
  },
};
