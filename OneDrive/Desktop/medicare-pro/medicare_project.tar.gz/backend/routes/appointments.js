const router = require('express').Router();
const c = require('../controllers/appointmentController');
const auth = require('./middleware');

router.get('/',      auth.any, c.getAll);
router.get('/:id',   auth.any, c.getById);
router.post('/',     auth.staff, c.create);
router.put('/:id',   auth.staff, c.update);

module.exports = router;
